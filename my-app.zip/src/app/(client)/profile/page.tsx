import RouteSetter from '@/components/RouteSetter';

export default function ProfilePage() {
    return <RouteSetter viewId="profile" />;
}
