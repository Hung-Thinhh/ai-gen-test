"use client";

import MainApp from "@/components/MainApp";
import { useAppControls } from "@/components/uiContexts";
import { useEffect } from "react";

export default function Home() {


  return <MainApp />;
}
