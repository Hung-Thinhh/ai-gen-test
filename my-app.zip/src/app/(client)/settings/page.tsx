import RouteSetter from '@/components/RouteSetter';

export default function SettingsPage() {
    return <RouteSetter viewId="settings" />;
}
