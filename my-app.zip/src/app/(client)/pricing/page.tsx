"use client";

import React from 'react';
import RouteSetter from '@/components/RouteSetter';

export default function PricingPage() {
    return <RouteSetter viewId="pricing" />;
}
