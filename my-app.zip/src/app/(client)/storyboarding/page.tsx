import RouteSetter from '@/components/RouteSetter';

export default function StoryboardingPage() {
    return <RouteSetter viewId="storyboarding" />;
}
