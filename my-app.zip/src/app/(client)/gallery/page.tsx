import RouteSetter from '@/components/RouteSetter';

export default function GalleryPage() {
    return <RouteSetter viewId="gallery" />;
}
