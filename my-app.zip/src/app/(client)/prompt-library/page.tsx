import RouteSetter from '@/components/RouteSetter';

export default function PromptLibraryPage() {
    return <RouteSetter viewId="prompt-library" />;
}
