import RouteSetter from '@/components/RouteSetter';

export default function GeneratorsPage() {
    return <RouteSetter viewId="generators" />;
}
