import BannerManagement from '@/components/admin/BannerManagement';

export default function BannersPage() {
    return <BannerManagement />;
}
