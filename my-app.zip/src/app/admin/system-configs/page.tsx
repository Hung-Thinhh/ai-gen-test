import SystemConfigManagement from '@/components/admin/SystemConfigManagement';

export default function SystemConfigsPage() {
    return <SystemConfigManagement />;
}
