"use client";

import DashboardOverview from '@/components/admin/DashboardOverview';

export default function AdminPage() {
    return <DashboardOverview />;
}
