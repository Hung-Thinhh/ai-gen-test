"use client";

import UserManagement from '@/components/admin/UserManagement';

export default function UsersPage() {
    return <UserManagement />;
}
