"use client";

import React from 'react';
import CategoryManagement from '@/components/admin/CategoryManagement';

export default function CategoriesPage() {
    return (
        <CategoryManagement />
    );
}
