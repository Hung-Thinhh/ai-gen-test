"use client";

import React from 'react';
import StudioManagement from '@/components/admin/StudioManagement';

export default function StudiosPage() {
    return (
        <StudioManagement />
    );
}
