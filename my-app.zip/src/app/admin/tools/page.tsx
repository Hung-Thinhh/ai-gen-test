"use client";

import ToolManagement from '@/components/admin/ToolManagement';

export default function ToolsPage() {
    return <ToolManagement />;
}
