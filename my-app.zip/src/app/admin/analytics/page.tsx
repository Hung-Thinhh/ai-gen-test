import Analytics from '../../../components/admin/Analytics';

export default function AnalyticsPage() {
    return <Analytics />;
}
