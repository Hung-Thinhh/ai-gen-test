"use client";

import Settings from '@/components/admin/Settings';

export default function SettingsPage() {
    return <Settings />;
}
