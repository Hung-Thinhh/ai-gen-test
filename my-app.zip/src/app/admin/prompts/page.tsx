"use client";

import PromptManagement from '@/components/admin/PromptManagement';

export default function PromptsPage() {
    return <PromptManagement />;
}
