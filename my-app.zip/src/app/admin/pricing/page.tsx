"use client";

import PricingManagement from '@/components/admin/PricingManagement';

export default function PricingPage() {
    return <PricingManagement />;
}
